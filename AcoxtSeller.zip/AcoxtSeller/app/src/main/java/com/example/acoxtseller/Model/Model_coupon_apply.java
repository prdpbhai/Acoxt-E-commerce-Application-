package com.example.acoxtseller.Model;

public class Model_coupon_apply {
    String coupon_code;

    public Model_coupon_apply(String coupon_code) {
        this.coupon_code = coupon_code;
    }

    public String getCoupon_code() {
        return coupon_code;
    }

    public void setCoupon_code(String coupon_code) {
        this.coupon_code = coupon_code;
    }
}
