package com.example.acoxtseller.Model;

public class Model_munchies {
    String category_name;

    public Model_munchies(String category_name) {
        this.category_name = category_name;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }
}
