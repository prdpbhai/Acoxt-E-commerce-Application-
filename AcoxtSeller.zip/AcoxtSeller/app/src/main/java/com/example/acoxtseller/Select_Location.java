package com.example.acoxtseller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Select_Location extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_location);
//        return null;
    }
}