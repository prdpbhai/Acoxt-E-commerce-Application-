package com.example.acoxtseller.Model;

import android.widget.TextView;

public class Model_Acoxt_discount {
    String home_prodname;

    public Model_Acoxt_discount(String home_prodname) {
        this.home_prodname = home_prodname;
    }

    public String getHome_prodname() {
        return home_prodname;
    }

    public void setHome_prodname(String home_prodname) {
        this.home_prodname = home_prodname;
    }
}
