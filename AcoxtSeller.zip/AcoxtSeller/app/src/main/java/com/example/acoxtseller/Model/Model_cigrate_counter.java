package com.example.acoxtseller.Model;

public class Model_cigrate_counter {
    String time,am;

    public Model_cigrate_counter(String time, String am) {
        this.time = time;
        this.am = am;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getAm() {
        return am;
    }

    public void setAm(String am) {
        this.am = am;
    }
}
