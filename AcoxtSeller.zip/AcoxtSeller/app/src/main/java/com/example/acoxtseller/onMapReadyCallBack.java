package com.example.acoxtseller;

import com.google.android.gms.maps.GoogleMap;

public interface onMapReadyCallBack {
    void onMapReddy(GoogleMap var1);
}
