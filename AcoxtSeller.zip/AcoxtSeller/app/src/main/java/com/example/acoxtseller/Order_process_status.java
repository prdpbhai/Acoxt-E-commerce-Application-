package com.example.acoxtseller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Order_process_status extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_process_status);
    }
}